# Meridian local admin preview

This is a standalone, local-only editor preview. It is separate from the public Meridian clock and has no publishing endpoint, account sign-in, server-side storage, or network integration.

## Run it

From this folder, run:

```sh
./start-local-preview.sh
```

Then open `http://127.0.0.1:8765/` in the same browser. You can also start the built-in server manually with `python3 -m http.server 8765 --bind 127.0.0.1`.

## Saving

The preview text and world-clock list update as you edit. Click **Save in this browser** to store the current version in this browser's `localStorage`. **Discard draft** returns the form to the last saved version. The saved copy is tied to this browser profile and this exact local address/port; it does not sync across devices and is not applied to the public clock. Clearing this site's browser storage removes the saved copy.

The app files themselves are static HTML, CSS, JavaScript, and the supplied icon. The included server only serves those files on loopback (`127.0.0.1`); it does not receive or store form data.

## Security limits

This is a convenience preview, not a secure admin product. Browser storage is not encrypted by this app and is accessible to someone with access to the browser profile. There is no password protection or account system. Do not enter passwords, secrets, or sensitive personal information.

## Files

- `index.html` — page structure and icon link
- `styles.css` — responsive layout and styling
- `app.js` — local preview rendering, validation, and browser-only saving
- `assets/clock-editor-icon.png` — the supplied clock artwork converted to PNG
- `start-local-preview.sh` — loopback-only local web server launcher
