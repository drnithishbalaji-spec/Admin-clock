(() => {
  'use strict';

  const STORAGE_KEY = 'meridian-local-admin-preview-v1';
  const DEFAULTS = {
    headline: 'The world, in its own time.',
    intro: 'A little more presence in every passing second.',
    note: 'A familiar face for the moment you’re in. Add the places that matter to keep their hours close, too.',
    places: [
      { city: 'London', zone: 'Europe/London' },
      { city: 'Tokyo', zone: 'Asia/Tokyo' },
      { city: 'New York', zone: 'America/New_York' }
    ]
  };
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const byId = id => document.getElementById(id);
  const validZone = zone => {
    if (typeof zone !== 'string' || !zone.trim()) return false;
    try { new Intl.DateTimeFormat('en', { timeZone: zone.trim() }); return true; }
    catch (_) { return false; }
  };
  const tidy = value => String(value ?? '').trim();
  const clone = value => JSON.parse(JSON.stringify(value));

  function cleanState(value) {
    if (!value || typeof value !== 'object') return clone(DEFAULTS);
    const places = Array.isArray(value.places) ? value.places.slice(0, 8).map(place => ({
      city: String(place?.city ?? '').trim().slice(0, 32),
      zone: String(place?.zone ?? '').trim().slice(0, 80)
    })).filter(place => place.city && validZone(place.zone)) : clone(DEFAULTS.places);
    return {
      headline: String(value.headline ?? DEFAULTS.headline).slice(0, 90),
      intro: String(value.intro ?? DEFAULTS.intro).slice(0, 140),
      note: String(value.note ?? DEFAULTS.note).slice(0, 240),
      places
    };
  }

  function readSavedState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return { state: clone(DEFAULTS), hasStoredState: false };
      return { state: cleanState(JSON.parse(raw)), hasStoredState: true };
    } catch (_) {
      return { state: clone(DEFAULTS), hasStoredState: false };
    }
  }

  const initialState = readSavedState();
  let savedState = initialState.state;
  let hasStoredState = initialState.hasStoredState;
  let localZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  let lastZoneList = [];

  function setSaveStatus(message, kind = '') {
    const status = byId('save-status');
    status.textContent = message;
    status.className = `save-status${kind ? ` ${kind}` : ''}`;
  }

  function collectForm() {
    const places = $$('.place-row').map(row => ({
      city: tidy($('.city-input', row).value),
      zone: tidy($('.zone-input', row).value)
    }));
    return {
      headline: tidy(byId('headline-input').value),
      intro: tidy(byId('intro-input').value),
      note: tidy(byId('note-input').value),
      places
    };
  }

  function statesEqual(a, b) { return JSON.stringify(a) === JSON.stringify(b); }

  function markDraft() {
    const draft = collectForm();
    updatePreview(draft);
    const changed = !statesEqual(draft, savedState);
    const message = changed ? 'Unsaved draft · not stored yet' : (hasStoredState ? 'Saved in this browser' : 'Sample loaded · not stored yet');
    setSaveStatus(message);
    if (changed) $('#save-status').classList.add('unsaved');
  }

  function setForm(state) {
    byId('headline-input').value = state.headline;
    byId('intro-input').value = state.intro;
    byId('note-input').value = state.note;
    byId('place-rows').replaceChildren();
    state.places.forEach(place => addPlaceRow(place));
    markDraft();
  }

  function addPlaceRow(place = { city: '', zone: '' }) {
    const list = byId('place-rows');
    if (list.children.length >= 8) {
      setSaveStatus('Up to 8 places can be shown in this preview.', 'error');
      return null;
    }
    const row = document.createElement('div');
    row.className = 'place-row';

    const cityField = document.createElement('label');
    cityField.className = 'place-field';
    const cityCaption = document.createElement('span');
    cityCaption.textContent = 'City';
    const cityInput = document.createElement('input');
    cityInput.className = 'place-input city-input';
    cityInput.type = 'text';
    cityInput.maxLength = 32;
    cityInput.autocomplete = 'off';
    cityInput.required = true;
    cityInput.value = place.city || '';
    cityInput.setAttribute('aria-label', 'World-clock city name');
    cityField.append(cityCaption, cityInput);

    const zoneField = document.createElement('label');
    zoneField.className = 'place-field';
    const zoneCaption = document.createElement('span');
    zoneCaption.textContent = 'IANA time zone';
    const zoneInput = document.createElement('input');
    zoneInput.className = 'place-input zone-input';
    zoneInput.type = 'text';
    zoneInput.maxLength = 80;
    zoneInput.autocomplete = 'off';
    zoneInput.required = true;
    zoneInput.placeholder = 'Europe/London';
    zoneInput.value = place.zone || '';
    zoneInput.setAttribute('aria-label', 'IANA time-zone identifier');
    zoneField.append(zoneCaption, zoneInput);

    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'remove-place';
    remove.textContent = '×';
    remove.setAttribute('aria-label', `Remove ${place.city || 'world-clock'} item`);
    remove.addEventListener('click', () => { row.remove(); markDraft(); });
    row.append(cityField, zoneField, remove);
    list.append(row);
    return row;
  }

  function formatCityZone(zone) {
    return String(zone).split('/').pop().replaceAll('_', ' ');
  }

  function zoneTime(date, zone) {
    return new Intl.DateTimeFormat(undefined, {
      timeZone: zone, hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
    }).format(date);
  }

  function zoneOffset(date, zone) {
    try {
      return new Intl.DateTimeFormat('en', { timeZone: zone, timeZoneName: 'shortOffset' })
        .formatToParts(date).find(part => part.type === 'timeZoneName')?.value || '';
    } catch (_) { return ''; }
  }

  function buildWorldCards(places) {
    const grid = byId('world-grid');
    grid.replaceChildren();
    lastZoneList = places.map(place => ({ ...place }));
    if (!places.length) {
      const empty = document.createElement('div');
      empty.className = 'world-empty';
      empty.textContent = 'No world-clock places yet. Add one in the local editor.';
      grid.append(empty);
      return;
    }
    places.forEach(place => {
      const card = document.createElement('article');
      card.className = 'world-card';
      const city = document.createElement('div');
      city.className = 'world-place';
      city.textContent = place.city || 'Unnamed place';
      const zoneName = document.createElement('div');
      zoneName.className = 'world-zone';
      zoneName.textContent = place.zone.replaceAll('_', ' ');
      const time = document.createElement('div');
      time.className = 'world-time';
      const meta = document.createElement('div');
      meta.className = 'world-meta';
      const date = document.createElement('span');
      date.className = 'world-date';
      const offset = document.createElement('span');
      offset.className = 'world-offset';
      meta.append(date, offset);
      card.append(city, zoneName, time, meta);
      grid.append(card);
    });
    updateWorldTimes(new Date());
  }

  function updateWorldTimes(now) {
    $$('.world-card').forEach((card, index) => {
      const place = lastZoneList[index];
      if (!place) return;
      try {
        $('.world-time', card).textContent = zoneTime(now, place.zone);
        $('.world-date', card).textContent = new Intl.DateTimeFormat(undefined, {
          timeZone: place.zone, weekday: 'short', month: 'short', day: 'numeric'
        }).format(now);
        $('.world-offset', card).textContent = zoneOffset(now, place.zone);
      } catch (_) {
        $('.world-time', card).textContent = 'Invalid zone';
        $('.world-date', card).textContent = 'Check the IANA time-zone ID';
        $('.world-offset', card).textContent = '';
      }
    });
  }

  function updatePreview(state) {
    byId('preview-headline').textContent = state.headline || 'Your clock headline';
    byId('preview-intro').textContent = state.intro || 'Your short introduction';
    byId('preview-note').textContent = state.note || 'Your clock note';
    byId('places-count').textContent = `${state.places.length} ${state.places.length === 1 ? 'PLACE' : 'PLACES'}`;
    buildWorldCards(state.places);
  }

  function tickClock() {
    const now = new Date();
    const formatter = new Intl.DateTimeFormat(undefined, {
      timeZone: localZone, hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
    });
    const parts = Object.fromEntries(formatter.formatToParts(now).map(part => [part.type, part.value]));
    let hour = Number(parts.hour) % 12;
    const minute = Number(parts.minute);
    const second = Number(parts.second);
    byId('top-date').textContent = new Intl.DateTimeFormat(undefined, {
      timeZone: localZone, weekday: 'short', month: 'short', day: 'numeric'
    }).format(now);
    byId('hero-time').innerHTML = `${parts.hour}:${parts.minute}<span class="seconds">:${parts.second} ${parts.dayPeriod || ''}</span>`;
    byId('hero-date').textContent = new Intl.DateTimeFormat(undefined, {
      timeZone: localZone, weekday: 'long', month: 'long', day: 'numeric', year: 'numeric'
    }).format(now);
    byId('local-label').textContent = `${formatCityZone(localZone)} · local time`;
    byId('footer-zone').textContent = localZone.replaceAll('_', ' ');
    byId('hour-hand').style.transform = `rotate(${(hour + minute / 60) * 30}deg)`;
    byId('minute-hand').style.transform = `rotate(${(minute + second / 60) * 6}deg)`;
    byId('second-hand').style.transform = `rotate(${second * 6}deg)`;
    byId('dial').setAttribute('aria-label', `Analog clock showing ${zoneTime(now, localZone)} local time`);
    updateWorldTimes(now);
  }

  function renderTicks() {
    const holder = byId('dial-ticks');
    const fragment = document.createDocumentFragment();
    for (let i = 0; i < 60; i += 1) {
      const tick = document.createElement('span');
      tick.className = `tick${i % 5 === 0 ? ' major' : ''}`;
      tick.style.transform = `translateX(-50%) rotate(${i * 6}deg)`;
      fragment.append(tick);
    }
    holder.append(fragment);
  }

  byId('editor-form').addEventListener('input', markDraft);
  byId('add-place').addEventListener('click', () => {
    const row = addPlaceRow({ city: 'Sydney', zone: 'Australia/Sydney' });
    if (row) {
      markDraft();
      $('.city-input', row).focus();
    }
  });
  byId('discard-button').addEventListener('click', () => {
    setForm(savedState);
    setSaveStatus(hasStoredState ? 'Draft discarded · saved browser copy restored' : 'Draft discarded · default sample restored');
  });
  byId('editor-form').addEventListener('submit', event => {
    event.preventDefault();
    const draft = collectForm();
    const headline = byId('headline-input');
    const intro = byId('intro-input');
    const note = byId('note-input');
    if (!headline.value.trim() || !intro.value.trim() || !note.value.trim()) {
      [headline, intro, note].find(input => !input.value.trim())?.focus();
      setSaveStatus('Please fill in all clock text fields before saving.', 'error');
      return;
    }
    if (draft.places.length > 8 || draft.places.some(place => !place.city || !validZone(place.zone))) {
      const invalid = $$('.place-row').find(row => !$('.city-input', row).value.trim() || !validZone($('.zone-input', row).value.trim()));
      invalid?.querySelector('input')?.focus();
      setSaveStatus('Each place needs a city name and a valid IANA time-zone ID.', 'error');
      return;
    }
    try {
      const normalized = cleanState(draft);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
        savedState = clone(normalized);
        hasStoredState = true;
        setForm(savedState);
        setSaveStatus('Saved in this browser · not sent anywhere');
    } catch (_) {
      setSaveStatus('This browser could not save local storage. Try serving this folder from localhost.', 'error');
    }
  });

  renderTicks();
  setForm(savedState);
  tickClock();
  window.setInterval(tickClock, 1000);
})();
